package com.sorting.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorting.entity.Country;


@Service
public class CountryService {

	private final com.sorting.repository.CountryRepository countryRepository;
	
	
	public CountryService(com.sorting.repository.CountryRepository countryRepository) {
		this.countryRepository = countryRepository;
	}
	
	   public Iterable<com.sorting.entity.Country> list() {
	        return countryRepository.findAll();
	    }

	    public Iterable<com.sorting.entity.Country> save(List<com.sorting.entity.Country> country) {
	        return countryRepository.saveAll(country);
	    }
	    
	    public Optional<Country> findByName(String name){
	    	return countryRepository.findByName(name);
	    }

}
