package com.sorting.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sorting.entity.Country;

@Repository
public interface CountryRepository extends JpaRepository<com.sorting.entity.Country, Long>{

	Optional<Country> findByName(String name);
}
