package com.sorting.controller;

import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sorting.entity.Country;
import com.sorting.service.CountryService;

@RestController
@RequestMapping("/api")
public class CountryController {

	@Autowired
	CountryService countryService;
	
	@GetMapping("/list")
	public Iterable<Country> list(){
		return countryService.list();
	}
	
	@GetMapping("/byName")
	public ResponseEntity<Country> getEntityByName(@RequestParam String name){
		Optional<Country> country = countryService.findByName(name);
		return country.map(ResponseEntity::ok).orElseGet(()->ResponseEntity.notFound().build());
	}
	
}
