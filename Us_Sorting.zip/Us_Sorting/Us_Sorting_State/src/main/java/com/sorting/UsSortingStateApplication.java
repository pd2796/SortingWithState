package com.sorting;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorting.entity.Country;
import com.sorting.service.CountryService;


@SpringBootApplication
public class UsSortingStateApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsSortingStateApplication.class, args);
	}
	  @Bean
	    CommandLineRunner runner(CountryService countryService) {
	        return args -> {
	            // read json and write to db
	            ObjectMapper mapper = new ObjectMapper();
	            TypeReference<List<Country>> typeReference = new TypeReference<List<Country>>(){};
	            InputStream inputStream = TypeReference.class.getResourceAsStream("data.json");
	            try {
	                List<Country> users = mapper.readValue(inputStream,typeReference);
	                countryService.save(users);
	                System.out.println("State Saved!");
	            } catch (IOException e){
	                System.out.println("State: " + e.getMessage());
	            }
	        };
	    }
}
