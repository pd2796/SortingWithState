package com.sorting.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "country")
public class Country {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "fips")
	private String fips;
	@Column(name="state")
	private String state;
	@Column(name="name")
	private String name;
	public String getFips() {
		return fips;
	}
	public void setFips(String fips) {
		this.fips = fips;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Country(String fips, String state, String name) {
		this.fips = fips;
		this.state = state;
		this.name = name;
	}
	
	
	public Country() {
	}
	@Override
	public String toString() {
		return "Country [fips=" + fips + ", state=" + state + ", name=" + name + "]";
	}
	
	
}